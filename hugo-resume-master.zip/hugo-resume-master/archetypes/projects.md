---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
featured: true
description: "Text used in summary on main page"
tags: ["techtags","used","in","website"]
image: ""
link: "URL linked from project details page"
fact: "Interesting little tidbit shown below image on summary and detail page"
weight: 500
sitemap:
  priority : 0.8
---
